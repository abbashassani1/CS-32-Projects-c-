

#include <ctime>
#include <cstdlib>
#include "Game.h"

int main()
{
    // initialize the random number generator.  (you don't need to
    // understand how this works.)
   srand(static_cast<unsigned int>(time(0)));

    // create a game
    // use this instead to create a mini-game:   game g(3, 3, 2);
    Game g(15, 18, 80);

    // play the game
    g.play();
}
// passed
//#include "Game.h"
//#include "Game.h"
//#include "Arena.h"
//#include "Arena.h"
//#include "Previous.h"
//#include "Previous.h"
//#include "Player.h"
//#include "Player.h"
//#include "Robot.h"
//#include "Robot.h"
//#include "globals.h"
//#include "globals.h"
//int main()
//{}
// this program not sure
//#include "Previous.h"
//int main()
//{
//	Previous prev(2, 2);
//	prev.dropACrumb(1, 1);
//	prev.showPreviousMoves();
//}
// passed
//#include "Robot.h"
//int main()
//{
//	Robot r(0, 1, 1);
//}
//passed
//#include "Player.h"
//int main()
//{
//	Player p(0, 1, 1);
//}
// passed
//#include "Arena.h"
//int main()
//{
//	Arena a(10, 18);
//	a.addPlayer(2, 2);
//}
// passed
//#include "globals.h"
//#include "Player.h"
//#include "Arena.h"
//int main()
//{
//	Arena a(10, 20);
//	Player p(&a, 2, 3);
//}
// passed
//#include "Arena.h"
//#include "Player.h"
//int main()
//{
//	Arena a(10, 20);
//	Player p(&a, 2, 3);
//}
// passed
//#include "Player.h"
//#include "Arena.h"
//int main()
//{
//	Arena a(10, 20);
//	Player p(&a, 2, 3);
//}
//passed
//#include "Arena.h"
//#include "Player.h"
//#include "Previous.h"
//#include "globals.h"
//int main()
//{
//	Arena a(2, 2);
//	a.addPlayer(1, 1);
//	a.player()->move(RIGHT);
//	a.player()->stand();
//	a.player()->move(DOWN);
//	a.thePrevious().showPreviousMoves();
//}
// passed
//#include "Player.h"
//#include "Arena.h"
//int main()
//{
//	Arena a(10, 20);
//	Player p(&a, 2, 3);
//	Robot r(&a, 1, 1);
//}
 //passed
//#include "globals.h"
//#include "Robot.h"
//#include "Player.h"
//int main()
//{
//	Arena a(10, 10);
//}
//passed
//#include "Previous.h"
//int main()
//{
//	Previous prev;
//}