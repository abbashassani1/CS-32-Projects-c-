#include <iostream>
#include "globals.h"
#include "Previous.h"
using namespace std;
/*The constructor initializes a Previous object that corresponds to an Arena with nRows 
rows and nCols columns. You may assume (i.e., you do not have to check) that it will be 
called with a first argument that does not exceed MAXROWS and a second that does 
not exceed MAXCOLS, and that neither argument will be less than 1.*/
Previous::Previous(int nRows, int nCols)
	:m_rows(nRows), m_colms(nCols)
{
	if (nRows < 1 || nCols < 1 || nRows > MAXROWS || nCols > MAXCOLS)
	{
		cout << "The Pervious is unvalid \n";
		exit(1);
	}
	for (int r = 0; r < m_rows; r++)
	{
		for(int c = 0; c < m_colms; c++)
		{
			m_grid[r][c] = 0;
		}
	}
}
 

void Previous::showPreviousMoves() const
{
    clearScreen();

    // Drawing  grids
    for (int r = 0; r < m_rows; r++)
    {
        for (int c = 0; c < m_colms; c++)
        {
            char ch = '.';
            int n = m_grid[r][c];
            if (n >= 26)
                ch = 'Z';
            else if (n > 0)
                ch = 'A' + n - 1;
            cout << ch;
        }
        cout << endl;
    }
    cout << endl;
}
/*The dropACrumb function is to be called to notify the Previous object that the player has 
arrived at or stayed at a grid point. The function returns false if row r, column c is not 
within bounds; otherwise, it returns true after recording what it needs to. This function 
expects its parameters to be expressed in the same coordinate system as the arena 
(e.g., row 1, column 1 is the upper-left-most position).*/
bool Previous::dropACrumb(int r, int c)
{
    if(c < 1 || r < 1 || c > m_rows || r > m_colms)
    {
        return false;
    }
    else 
    {
        m_grid[r - 1][c - 1] += 1;
        return true;
    }
	
}