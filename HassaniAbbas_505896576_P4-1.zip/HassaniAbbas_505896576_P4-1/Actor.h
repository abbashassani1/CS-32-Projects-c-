#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameConstants.h"
#include "StudentWorld.h"

class Actor : public GraphObject
{
	public:
		//constructor for actor class
		Actor(StudentWorld* world, int imageID, int startX, int startY, Direction s_direction, double size, unsigned int depth);
		
		//destructor for actor class
		virtual ~Actor();

		//declartion of getworld function
		StudentWorld* getWorld();

		//pure virtual 
		virtual void doSomething() = 0;

	private:
		StudentWorld* m_world;
};

//define a tunnelman class
class TunnelMan: public Actor
{
	public: 
		//destructor for tunnelman
		//TunnelMan(StudentWorld* world, int imageID, int startX, int startY, Direction starDirection, double size, unsigned int depth);
		TunnelMan(StudentWorld* world);


		//destructor for tunnelman
		virtual ~TunnelMan();
		
		//declaring doSomething function
		virtual void doSomething();
		

};

class Earth : public Actor
{
	public:
		//Earth(StudentWorld* world, int imageID, int startX, int startY, Direction starDirection, double size, unsigned int depth);
		Earth(StudentWorld* world, int startX, int startY);

		//destructor for Earth class
		virtual ~Earth();

		//dectarin of doSomething function
		virtual void doSomething();
};



// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

#endif // ACTOR_H_
