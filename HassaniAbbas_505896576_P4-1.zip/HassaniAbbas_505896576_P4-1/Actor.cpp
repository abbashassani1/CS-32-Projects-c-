#include "Actor.h"
#include "StudentWorld.h"
#include "GraphObject.h"
#include "GameConstants.h"


// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp
Actor::Actor(StudentWorld* world,int imageID, int startX, int startY, Direction s_direction, double size, unsigned int depth)
	: GraphObject(imageID, startX, startY, s_direction, size, depth), m_world(world)
{
	setVisible(true);
}

//destructor implementation for actor class
Actor::~Actor()
{
}


// Define the getWorld() function
StudentWorld* Actor::getWorld() 
{
	return m_world;
}


//contructor implementation for tunnelman
//TunnelMan::TunnelMan(StudentWorld* world, int imageID, int startX, int startY, Direction starDirection, double size, unsigned int depth)
TunnelMan::TunnelMan(StudentWorld* world)
	:Actor(world, TID_PLAYER, 30, 60, right, 1.0, 0)
{
	setVisible(true);
}


//destructor implementation for tunnelman
TunnelMan::~TunnelMan()
{
}


void TunnelMan::doSomething()
{

		int ch;
	if (getWorld()->getKey(ch) == true)
	{
		// user hit a key this tick! 
		switch (ch)
		{
		case KEY_PRESS_LEFT:
			//move to left
			if(getDirection() == left && getX() >=1 )
			{
				moveTo(getX() - 1, getY());
			}
			else 
			{
				setDirection(left);
			}
			break;
		case KEY_PRESS_RIGHT:

			//move to right
			if(getDirection() == right && getX() <= 59)
			{
				moveTo(getX() + 1, getY());
			}
			else
			{
				setDirection(right);
			}
			break;
		case KEY_PRESS_UP:

			//move to up
			if(getDirection() == up && getY() <= 59) 
			{
				moveTo(getX(), getY() + 1);
			}
			else
			{
				setDirection(up);
			}
			break;
		case KEY_PRESS_DOWN:

			//move to down
			if (getDirection() == down && getY() >= 1)
			{
				moveTo(getX(), getY() - 1);
			}
			else
			{
				setDirection(down);
			}
			break;
		case KEY_PRESS_SPACE:
			//... add a Squirt in front of the player...;
			break;
			// etc�
		}
	}
	
}

//contru
//Earth::Earth(StudentWorld* world, int imageID, int startX, int startY, Direction starDirection, double size, unsigned int depth)
Earth::Earth(StudentWorld* world, int startX, int startY)
	:Actor(world, TID_EARTH, startX, startY, right, 0.25, 3)
{
	setVisible(true);
}

Earth::~Earth()
{
}

void Earth::doSomething()
{
	//do nothing 
}

