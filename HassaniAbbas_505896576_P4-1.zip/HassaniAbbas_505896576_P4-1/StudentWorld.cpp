
#include "StudentWorld.h"
#include "Actor.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}


//StudentWorld::~StudentWorld()
//{
//}
// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp


//implemetation of createoilfield function
void StudentWorld::createOilField()
{
	//wide of the oil field
	for(int i = 0; i < 64; i++)
	{
		//hight of oil field
		for(int j = 0; j < 60; j++)
		{
			if( i < 30 || i > 33 || j < 4)
			{
				m_earth[i][j] = new Earth(this, i, j);
			}
		}
	}
}



int StudentWorld::init()
{
	
	m_players = new TunnelMan(this);

	//create a funcition to make oil field
	 createOilField();

	return GWSTATUS_CONTINUE_GAME;
}


//implementation of clear the earth
void StudentWorld::clearEarth(int x, int y)
{
	// Iterate over a 4x4 grid starting from the provided (x, y) coordinates.
	for (int r = x; r < x + 4; r++)
	{
		for (int c = y; c < y + 4; c++)
		{
			//// test if the current grid position is in valid boundaries.
			if (r >= 0 && r < 64 && c >= 0 && c < 60)
			{
				//// teste if there is object  at the current position.
				if (m_earth[r][c] != nullptr)
				{
					// Delete the m_earth at the current position
					delete m_earth[r][c];
					// Play a digging sound
					playSound(SOUND_DIG);
					// set the m_earth pointer to nullptr.
					m_earth[r][c] = nullptr;
				}
			}
		}
	}
}

//implementation of move 
int StudentWorld::move()
{
	m_players->doSomething();

	int p = m_players->getX();
	int q = m_players->getY();

	clearEarth(p, q);
	return GWSTATUS_CONTINUE_GAME;
}
 

 void StudentWorld::cleanUp()
{
	 //wide of the oil field
	 for (int i = 0; i < 64; i++)
	 {
		 //hight of oil field
		 for (int j = 0; j < 60; j++)
		 {
			 delete m_earth[i][j];
		 }
	 }
	 delete m_players;

}