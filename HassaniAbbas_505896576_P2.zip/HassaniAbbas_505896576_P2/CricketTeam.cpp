#include <iostream>
#include "CricketTeam.h"
using namespace std;
// Create an empty CricketTeam list
CricketTeam::CricketTeam() :head(nullptr), size(0)
{
}

// copy constructor 
CricketTeam::CricketTeam(const CricketTeam& other)
{
	size = 0;
	head = nullptr;
	Node* p = other.head;//declare a node pointer to pointhe rhs head.
	Node* q = nullptr;
	
	if (p == nullptr)//checking if the rhs is empty.
		return;

	while (p != nullptr)
	{
		//copy into the new node.
		Node* newNode = new Node;
		newNode->value = p->value;
		newNode->first_name = p->first_name;
		newNode->last_name = p->last_name;
		newNode->next = nullptr;
		newNode->previous = nullptr;
		if (head == nullptr)// process it if the head is empty.
		{
			head = newNode;
			q = head;
		}
		else
		{
			//move the next node and previous.
			q->next = newNode;
			newNode->previous = q;
			q = q->next;
			
		}

		p = p->next;//move to next iteration.
	}
}

// Destroys all the dynamically allocated memory
// in the list. 
CricketTeam::~CricketTeam()
{
	Node* i = head;
	while (i != nullptr)// loop through the linked list.
	{
		Node* temp = i;//assign the i to temp.
		i = i->next;
		delete  temp;//This removes the node from the linked list and free the memory.
	}
};

// assignment operator 
//this this from hw1
const CricketTeam& CricketTeam::operator=(const CricketTeam& rhs)
{
	//check the conditions 
	if (this != &rhs)
	{
		CricketTeam p(rhs);// assign the rhs to p.
		tradeCricketTeams(p);
	}
	return *this;
}

// Return true if the CricketTeam list 
// is empty, otherwise false.
bool CricketTeam::noTeam() const 
{  
	Node* p = head;
	if (p == nullptr) //checks if the cricketteam list is empty.
	{
		return true;
	}
	else 
	{
		return false;
	}
	
}

// Return the number of matches 
// on the CricketTeam list.
int CricketTeam::cricketerCount() const
{
	int count = 0;//declare variabl co nt and initialize to zero.
	Node* p = head;
	while (p != nullptr)//this loop iterates untill it reach at the end of linked list.
	{
		count++;
		p = p->next;
	}
	return count;//return the size of cricketer.
	
}

// If the full name (both the first and last name) is not equal 
 // to any full name currently in the list then add it and return 
 // true. Elements should be added according to their last name. 
 // Elements with the same last name should be added according to
 // their first names. Otherwise, make no change to the list and
 // return false (indicating that the name is already in the 
 // list).
bool CricketTeam::addCricketer(const std::string& firstName, const std::string&
	lastName, const CricketType& value) 
{
	if(rosteredOnCricketTeam(firstName, lastName))
	{
		return false;
	}
	else
	{
		//creating a new node to hold the new crickter.
		Node* new_node = new Node;
		new_node->first_name = firstName;
		new_node->last_name = lastName;
		new_node->value = value;
		new_node->next = nullptr;
		new_node->previous = nullptr;
		Node* p = head;
		//if the linked list is empty and add a new like a head.
		if (p == nullptr) 
		{
			head = new_node;
			size++;// adding the size.
			return true;
		}
		p = nullptr;
		Node* q = nullptr;
		p = head;
		
		//now if the linked list is not empty, finding a right place to put a new cricketer.
		while(p != nullptr)
		{
			
			if(p->last_name > lastName)//comparing the last names.
			{
				//assign the new_node with p.
				new_node->next = p;
				new_node->previous = p->previous;
				if(p->previous != nullptr)
				{
					p->previous->next = new_node;
				}
				else
				{
					head = new_node;
				}
				p->previous = new_node;
				size++;
				return true;
			}
			else if(p->first_name >= firstName && p->last_name == lastName)//checking if last names are equal and the first name p points to with firstName.
			{
				//assign the node pointrs with p node pointer.
				new_node->next = p;
				new_node->previous = p->previous;
				if(p->previous != nullptr)
				{
					p->previous->next = new_node;
				}
				else
				{
					head = new_node;
				}
				size++;// adding the size.
				p->previous = new_node;
				return true;

			}
			q = p;//asiign the q node pointer to p node pointer.
			p = p->next;
		}
		q->next = new_node;
		new_node->previous = q;
		size++;
		return true;
	}
	
}

// If the full name is equal to a full name currently in the 
// list, then make that full name no longer map to the value it 
// currently maps to, but instead map to the value of the third 
// parameter; return true in this case. Otherwise, make no 
// change to the list and return false.
bool CricketTeam::substituteCricketer(const std::string& firstName, const
	std::string& lastName, const CricketType& value) 
{
	Node* p = head;
	while(p != nullptr)//loop through the linket list.
	{ 
		if(firstName == p->first_name && lastName == p->last_name)//checks the condition for the full name is equal to full name currently in the list.
		{
			p->value = value;// assign the value to p->value.
			return true;
		}
		
		p = p->next;
	}
	return false;
}

// If full name is equal to a name currently in the list, then
// make that full name no longer map to the value it currently 
// maps to, but instead map to the value of the third parameter; 
// return true in this case. If the full name is not equal to 
// any full name currently in the list then add it and return 
// true. In fact, this function always returns true.
bool CricketTeam::addOrSubstitute(const std::string& firstName, const
	std::string& lastName, const CricketType& value) 
{ 
	if(rosteredOnCricketTeam(firstName, lastName))// calls the rostereOnCricket to check, the person is in list.
	{
		substituteCricketer(firstName, lastName, value);//calls substituatesCrickter to substitutes.
		return true;
	}
	else
	{
		addCricketer(firstName, lastName, value);// calls the oddCricketer to add a preson in list.
		return true;
	}
}

// If the full name is equal to a full name currently in the 
// list, premove the full name and value from the list and return 
// true. Otherwise, make no change to the list and return 
// false.
bool CricketTeam::releaseCricketer(const std::string& firstName, const
	std::string& lastName) 
{
	Node* p = head;
	//Node* q = nullptr;
	
	while(p != nullptr)// loop to iterates through linked list.
	{
		if(firstName == p->first_name && lastName == p->last_name)// checking the conditon.
		{
			if(p->previous == nullptr)//romve the fisrt node.
			{
				head = p->next;
				p->next->previous = nullptr;
				delete p;
				return true;
			}
			else if (p->next == nullptr)//remove the last node.
			{
				p->previous->next = nullptr;
				delete p;
				return true;
			}
			else // remove a node somewhere in the middle.
			{
				p->previous->next = p->next;
				p->next->previous = p->previous;
				//q = p->next;// keep the p point to next.
				delete p;
			
				//p = q;// immportant for iteration of the loop, otherwise the program crash.
				return true;
			}
			
		}
		p = p->next;
	}
	return false;
}

// Return true if the full name is equal to a full name 
// currently in the list, otherwise false.
bool CricketTeam::rosteredOnCricketTeam(const std::string& firstName, const
	std::string& lastName) const 
{
	Node* p = head;
	while(p != nullptr)// loop that iterats through linked list.
	{
		if(firstName == p->first_name && lastName == p->last_name)// check the full name is equal to a full name currenctly in the list.
		{
			return true;//check with friends.
		}
		p = p->next;
	}
	return false;
}

// If the full name is equal to a full name currently in the 
// list, set value to the value in the list that that full name 
// maps to, and return true. Otherwise, make no change to the 
// value parameter of this function and return false.
bool CricketTeam::searchForCricketer(const std::string& firstName, const
	std::string& lastName, CricketType& value) const 
{ 
	Node* p = head;
	while (p != nullptr)//loop through the liked list.
	{
		if(firstName == p->first_name && lastName == p->last_name )//check the condition for the full name is equal to a full name currently in the list.
		{
			value = p->value;//assign the value p points to the value.
			return true;
		}
	
		p = p->next;
	}
	return false;
}

// If 0 <= i < size(), copy into firstName, lastName and value 
// parameters the corresponding information of the element at
// position i in the list and return true. Otherwise, leave the 
// parameters unchanged and return false. (See below for details 
// about this function.)
bool CricketTeam::checkTeamForCricketer(int i, std::string& firstName,
	std::string& lastName, CricketType& value) const 
{
	if (0 <= i && i < cricketerCount()) 
	{
		Node* p = head;
		for (int j = 0; j < i; j++)// loop to iterates untill the position i
		{
			p = p->next;
		}
		// at the position i,  assign the firstName, lastName and value and return true.
		firstName = p->first_name;
		lastName = p->last_name;
		value = p->value;
		return true; 
	}
	return false;// if the 0 <= i && i < cricketerCount() is not true and return false.
}

// Exchange the contents of this list with the other one.
void CricketTeam::tradeCricketTeams(CricketTeam& other) 
{
	Node* temp = head;//make a node pointer to to node.
	head = other.head;// copy the other.head to head.
	other.head = temp;// copy the head to other.head.

	// Swap the sizes to  for updating the number of cricketers in each list.
	int temp_size = size;
	size = other.size;
	other.size = temp_size;
}
// this is  margeCricketer 
bool mergeCricketers(const CricketTeam& odOne, const CricketTeam& odTwo, CricketTeam& odJoined)
{
	// Initialize the joinedTeam
	odJoined = CricketTeam();

	// loop through the cricketers,add from odOne into odJoined
	for (int i = 0; i < odOne.cricketerCount(); i++)
	{
		//initialize variables.
		std::string firstName, lastName;
		CricketType value;
		//check if the cricketers and add them into odJoined.
		if (odOne.checkTeamForCricketer(i, firstName, lastName, value))
		{
			//call te addCricketer to add the cricketer inot odJoined.
			odJoined.addCricketer(firstName, lastName, value);
		}
	}

	// loop though and add cricketer from odTwo into odJoined
	for (int i = 0; i < odTwo.cricketerCount(); i++)
	{
		//declare variables 
		std::string firstName, lastName;
		CricketType value;
		//check if 
		if (odTwo.checkTeamForCricketer(i, firstName, lastName, value))
		{
			//check the condition that the cricketer is in odJoined already.
			if (!odJoined.rosteredOnCricketTeam(firstName, lastName))
			{
				//add the cricketer in the odJoined.
				odJoined.addCricketer(firstName, lastName, value);
			}
		}
	}

	// Check for cricketers with different corresponding values
	for (int i = 0; i < odJoined.cricketerCount(); i++)
	{
		std::string firstName, lastName;
		CricketType value2, value1;
		//check the condition that 
		if (odJoined.checkTeamForCricketer(i, firstName, lastName, value1) && odTwo.searchForCricketer(firstName, lastName, value2) &&
			value1 != value2)
		{
			odJoined.releaseCricketer(firstName, lastName);
			return false; // Cricketers with different corresponding values.
		}
	}

	return true; // All cricketers are added successfully.
}

// the checkCricketr function
void checkCricketers(const std::string& fsearch, const std::string& lsearch, const CricketTeam& odOne, CricketTeam& odResult) {
	// obtain the number of cricketers in the CricketTeam odOne
	int count = odOne.cricketerCount();
	CricketTeam p;
	std::string firstName, lastName;
	CricketType value;
	// Loop through all the cricketers in odOne
	for (int i = 0; i < count; i++) {

		// obtain the details of the current cricketer at index i
		odOne.checkTeamForCricketer(i, firstName, lastName, value);

		// Check if the first name matches the fsearch or if fsearch is "*", which means any first name will match
		// and if the last name matches the lsearch or if lsearch is "*", which means any last name will match
		if ((fsearch == "*" || firstName == fsearch) && (lsearch == "*" || lastName == lsearch)) {
			// If the cricketer matches the search criteria, add it.
			p.addCricketer(firstName, lastName, value);
		}
	}
	odResult = p;//assign p to odResult;
}